Qt.include("factorial.js")

function showCalculations(value) {
    console.log("Call factorial() from script.js:",
                factorial(value));
}
