function jsFunction() {
    console.log("Called JavaScript function!")
}

