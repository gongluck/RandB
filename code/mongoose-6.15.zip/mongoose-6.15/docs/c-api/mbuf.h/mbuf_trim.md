---
title: "mbuf_trim()"
decl_name: "mbuf_trim"
symbol_kind: "func"
signature: |
  void mbuf_trim(struct mbuf *);
---

Shrinks an Mbuf by resizing its `size` to `len`. 

