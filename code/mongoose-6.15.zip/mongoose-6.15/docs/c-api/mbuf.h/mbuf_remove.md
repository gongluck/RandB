---
title: "mbuf_remove()"
decl_name: "mbuf_remove"
symbol_kind: "func"
signature: |
  void mbuf_remove(struct mbuf *, size_t data_size);
---

Removes `data_size` bytes from the beginning of the buffer. 

