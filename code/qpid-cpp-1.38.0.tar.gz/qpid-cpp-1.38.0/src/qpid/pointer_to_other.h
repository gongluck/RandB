#ifndef QPID_POINTERTOOTHER_H
#define QPID_POINTERTOOTHER_H

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */

namespace qpid {

// Defines the same pointer type (raw or smart) to another pointee type

template<class T, class U>
struct pointer_to_other;

template<class T, class U,
                  template<class> class Sp>
struct pointer_to_other< Sp<T>, U >
                  {
                      typedef Sp<U> type;
                  };

template<class T, class T2, class U,
         template<class, class> class Sp>
struct pointer_to_other< Sp<T, T2>, U >
         {
             typedef Sp<U, T2> type;
         };

template<class T, class T2, class T3, class U,
         template<class, class, class> class Sp>
struct pointer_to_other< Sp<T, T2, T3>, U >
         {
             typedef Sp<U, T2, T3> type;
         };

template<class T, class U>
struct pointer_to_other< T*, U >
{
    typedef U* type;
};

} // namespace qpid



#endif  /*!QPID_POINTERTOOTHER_H*/
