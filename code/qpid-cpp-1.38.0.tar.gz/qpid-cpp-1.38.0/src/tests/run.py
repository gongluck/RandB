#!/usr/bin/env python

from common import *

call(" ".join(ARGS[1:]))

