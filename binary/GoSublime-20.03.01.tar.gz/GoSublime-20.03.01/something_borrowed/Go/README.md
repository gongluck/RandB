This is a copy of https://github.com/sublimehq/Packages/tree/master/Go with the annoying parts excluded.

Run `go generate` to re-generate it.
