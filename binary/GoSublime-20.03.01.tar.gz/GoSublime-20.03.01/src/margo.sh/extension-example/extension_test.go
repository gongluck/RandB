package margo

import (
	"margo.sh/mg"
)

var _ mg.MargoFunc = Margo
