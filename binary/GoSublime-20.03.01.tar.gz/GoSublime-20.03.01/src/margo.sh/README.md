[![Build Status](https://travis-ci.org/KurokuLabs/margo.svg?branch=master)](https://travis-ci.org/KurokuLabs/margo)

<hr>

# margo

This project is the next step in the evolution of https://github.com/DisposaBoy/GoSublime...
this time with less Python, less Sublime Text and more Go.

### Warning

This repo is made public at this time solely to make it easier to integrate with GoSublime.

It is under very active experimental development and code may be broken or deleted at any time.


## License & Contributing

margo is released under the MIT license. See [LICENSE.md](LICENSE.md)

See [CONTRIBUTING.md](CONTRIBUTING.md) for details about contributing to the project.

