package mg

type Tooltip struct {
	Content string
}
