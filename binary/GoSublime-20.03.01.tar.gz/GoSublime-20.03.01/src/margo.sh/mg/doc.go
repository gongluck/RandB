package mg // import "margo.sh/mg"
