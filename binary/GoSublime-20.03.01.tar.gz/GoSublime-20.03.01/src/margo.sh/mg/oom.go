package mg

const (
	DefaultMemoryLimit = 2 << 30
)
