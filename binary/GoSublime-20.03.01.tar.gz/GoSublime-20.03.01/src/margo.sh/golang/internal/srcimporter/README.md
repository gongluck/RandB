This is a fork of go/internal/srcimporter

