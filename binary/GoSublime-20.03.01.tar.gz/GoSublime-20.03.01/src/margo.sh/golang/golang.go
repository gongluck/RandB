package golang

import (
	"margo.sh/mg"
)

var Reducers = []mg.Reducer{}
