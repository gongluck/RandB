package mgutil

import (
	"margo.sh/memo"
)

type Memo = memo.M
