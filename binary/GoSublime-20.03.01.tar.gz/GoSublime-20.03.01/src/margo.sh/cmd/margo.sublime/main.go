package main

import (
	"margo.sh/cmdpkg/margosublime"
)

func main() {
	margosublime.Main()
}
