package main // import "margo.sh"

import (
	"margo.sh/cmdpkg/margo"
)

func main() {
	margo.Main()
}
