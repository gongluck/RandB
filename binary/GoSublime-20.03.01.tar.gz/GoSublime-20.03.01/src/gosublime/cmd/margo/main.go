package main

import (
	"gosublime/cmd/margo_pkg"
)

func main() {
	margo_pkg.Main()
}
