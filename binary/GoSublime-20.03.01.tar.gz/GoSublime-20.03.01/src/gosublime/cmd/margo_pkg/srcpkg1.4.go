// +build go1.4

package margo_pkg

const SrcPkg = "src"
