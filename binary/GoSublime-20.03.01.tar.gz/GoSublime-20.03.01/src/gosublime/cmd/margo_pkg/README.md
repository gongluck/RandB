License
=======

MIT http://disposaboy.mit-license.org/