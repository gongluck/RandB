
def gs_init(m={}):
	pass
